package lms_with_files_v3;

import java.io.IOException;

public class LibraryManagement {

    public static void main(String[] args) throws IOException {
        Librarian li = new Librarian();
        li.options();
    }
}