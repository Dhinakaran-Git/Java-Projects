package application.lms.model.jpaModel;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "lms_IssueBooks")
public class IssueBooks {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IssueBook_id")
    private int issueBookId;

    @Column(name = "In_Date")
    private String inDate;

    @Column(name = "Out_Date")
    private String outDate;

    @Column(name = "Member_id")
    private int memberId;

    @Column(name = "BookCopies_id")
    private int bookCopiesId;

    @Column(name = "Is_returned")
    private boolean isReturned;
    
    @ManyToOne
    @JoinColumn(name = "BookCopies_id", insertable=false, updatable=false)
    private BookCopies bookcopies;

    public IssueBooks(int issueBookId, String outDate, int memberId, int bookCopiesId, boolean isReturned) {
        this.issueBookId = issueBookId;
        this.outDate = outDate;
        this.memberId = memberId;
        this.bookCopiesId = bookCopiesId;
        this.isReturned = isReturned;
    }
}
