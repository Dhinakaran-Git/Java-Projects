package application.lms.dao;

public interface IssueBookDAO {
            
    public void addIssueBook();

    public void issuedBooks();

}
