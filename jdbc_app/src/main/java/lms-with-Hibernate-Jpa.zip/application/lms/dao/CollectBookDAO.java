package application.lms.dao;

public interface CollectBookDAO {

    public void collectBook();

    public void collectedBooks();
}
